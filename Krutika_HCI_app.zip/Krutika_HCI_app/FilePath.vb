﻿Public Class FilePathManager
    Public Shared Property StudentDataFilePath As String = "C:\Users\aniket\Desktop\New_Driving_School_App\RoadWarriorsDrivingSchool\StudentsData.txt"
    Public Shared Property TraineeDataFilePath As String = "C:\Users\aniket\Desktop\New_Driving_School_App\RoadWarriorsDrivingSchool\TraineeData.txt"

End Class
